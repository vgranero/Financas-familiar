import { useState, useRef, useCallback, useMemo, useEffect } from "react";

const FONT = "https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap";

const DEFAULT_CATS = {
  receita: ["Salário Líquido","Gratificação / Bônus","PLR / Remuneração Variável","Reembolso","Dividendos","Aluguel Recebido","Outros"],
  gasto: ["Alimentação","Restaurante","Padaria / Café","Supermercado","Farmácia","Saúde / Clínica","Plano de Saúde","Transporte / Uber","Combustível","Estacionamento","Moda / Vestuário","Casa / Moradia","Seguro Residencial","Seguro Veículo","Educação","Lazer / Entretenimento","Academia / Bem-estar","Viagem / Hospedagem","Serviços Digitais","Anuidade Cartão","Encargos / Juros","Outros"],
  investimento: ["PGBL / Previdência","Renda Fixa","Renda Variável / Ações","Bônus Diferido Ações","Fundos","Tesouro Direto","Criptomoedas","Imóveis","Outros"],
};

const fmt = v => new Intl.NumberFormat("pt-BR",{style:"currency",currency:"BRL"}).format(v||0);
const fmtShort = v => { const a=Math.abs(v); if(a>=1e6) return `R$${(v/1e6).toFixed(1)}M`; if(a>=1e3) return `R$${(v/1e3).toFixed(0)}k`; return fmt(v); };
const today = () => new Date().toISOString().slice(0,10);
const monthKey = d => d.slice(0,7);
const MONTH_NAMES=["Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"];
const monthLabel = k => { const [y,m]=k.split("-"); return `${MONTH_NAMES[+m-1]}/${y.slice(2)}`; };
const quarterKey = d => { const [y,m]=d.slice(0,7).split("-"); return `${y}-T${Math.ceil(+m/3)}`; };
const quarterLabel = k => k.replace("-","");

// ─── SEED DATA — todos os documentos reais ────────────────────────────────────
let _id = 1;
const mk = (tipo,cat,desc,valor,data,origem="pdf",fonte="",recorrente=false,recorrencia="mensal",titular="Vitor") =>
  ({id:_id++,tipo,categoria:cat,descricao:desc,valor,data,origem,fonte,recorrente,recorrencia,titular});

const SEED = [
  // ══════════════════════════════════════════════════════════
  // HOLERITES SANTANDER
  // ══════════════════════════════════════════════════════════
  mk("receita","Salário Líquido","Salário Santander - Jan/26",21656.57,"2026-01-30","pdf","Holerite Mensal 01/2026",true),
  mk("investimento","PGBL / Previdência","PGBL Renda Fixa - Jan/26",2839.97,"2026-01-30","pdf","Holerite Mensal 01/2026",true),
  mk("gasto","Plano de Saúde","Assist. Médica SulAmérica - Jan/26",1612.38,"2026-01-30","pdf","Holerite Mensal 01/2026",true),
  mk("receita","Salário Líquido","Salário Santander - Fev/26",23063.90,"2026-02-27","pdf","Holerite Mensal 02/2026",true),
  mk("investimento","PGBL / Previdência","PGBL Renda Fixa - Fev/26",2839.97,"2026-02-27","pdf","Holerite Mensal 02/2026",true),
  mk("gasto","Plano de Saúde","Assist. Médica SulAmérica - Fev/26",1612.38,"2026-02-27","pdf","Holerite Mensal 02/2026",true),
  mk("receita","PLR / Remuneração Variável","PLR + Bônus Santander - Fev/26",573031.42,"2026-02-27","pdf","Holerite RV 02/2026"),

  // ══════════════════════════════════════════════════════════
  // FATURA PORTO BANK (cartão *120)
  // ══════════════════════════════════════════════════════════
  mk("gasto","Seguro Veículo","Porto Seguro Auto - Parcela 11/12",365.29,"2025-12-27","pdf","Fatura Porto Bank Jan/26"),
  mk("gasto","Anuidade Cartão","Anuidade Diferenciada Porto - 10/12",54.00,"2025-11-25","pdf","Fatura Porto Bank Jan/26"),
  mk("gasto","Serviços Digitais","Cartão Protegido Porto",9.99,"2025-12-25","pdf","Fatura Porto Bank Jan/26"),
  mk("gasto","Seguro Veículo","Porto Seguro Auto - Parcela 12/12",365.23,"2026-01-27","pdf","Fatura Porto Bank Fev/26"),
  mk("gasto","Anuidade Cartão","Anuidade Diferenciada Porto - 11/12",54.00,"2025-12-25","pdf","Fatura Porto Bank Fev/26"),
  mk("gasto","Encargos / Juros","Multa por Atraso - Porto Bank",8.58,"2026-01-02","pdf","Fatura Porto Bank Fev/26"),
  mk("gasto","Encargos / Juros","Juros de Mora - Porto Bank",0.28,"2026-01-26","pdf","Fatura Porto Bank Fev/26"),
  mk("gasto","Serviços Digitais","Cartão Protegido Porto",14.90,"2026-01-26","pdf","Fatura Porto Bank Fev/26"),
  mk("gasto","Seguro Veículo","Porto Seguro Auto - Parcela 01/12",398.24,"2026-01-27","pdf","Fatura Porto Bank Mar/26",true),
  mk("gasto","Anuidade Cartão","Anuidade Diferenciada Porto - 12/12",54.00,"2026-01-27","pdf","Fatura Porto Bank Mar/26"),
  mk("gasto","Serviços Digitais","Cartão Protegido Porto",14.90,"2026-02-23","pdf","Fatura Porto Bank Mar/26"),

  // ══════════════════════════════════════════════════════════
  // FATURA AADVANTAGE BLACK *3313 — JAN/26 (venc 30/01)
  // período 23/12/25 a 23/01/26
  // ══════════════════════════════════════════════════════════
  // Parcelamentos
  mk("gasto","Lazer / Entretenimento","Tropicarim Pousada 03/03",224.61,"2025-11-20","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Moda / Vestuário","TNF Loja 68 02/02",219.50,"2025-11-27","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Moda / Vestuário","MNR Bling Comércio 02/02",199.00,"2025-12-14","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Moda / Vestuário","Foxton Iguatemi JK 02/03",490.68,"2025-12-14","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Alimentação","Mistral Importadora 02/03",397.59,"2025-12-17","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Eletrônicos","Lojas iPlace 02/02",199.50,"2025-12-20","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Moda / Vestuário","Vix Varejo - Vila Nova 01/03",282.68,"2026-01-15","pdf","AAdvantage *3313 Jan/26"),
  // Despesas
  mk("gasto","Supermercado","Pão de Açúcar",94.29,"2025-12-13","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Lazer / Entretenimento","Poderoso Timão",158.99,"2025-12-21","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Farmácia","Casa Granado",60.00,"2025-12-21","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Farmácia","Raia",73.05,"2025-12-21","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Padaria / Café","Paes e Doces Manhattan",39.60,"2025-12-21","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Padaria / Café","Dengo Chocolatessa",24.90,"2025-12-21","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Padaria / Café","Cafe Caoc",48.45,"2025-12-22","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Restaurante","Andiamo",154.26,"2025-12-22","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Restaurante","Bar Dois Irmãos",260.00,"2025-12-23","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Restaurante","Rascal",164.96,"2025-12-23","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Padaria / Café","Paes e Doces Manhattan",37.52,"2025-12-24","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Moda / Vestuário","Arezzo Iguatemi",149.90,"2025-12-24","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Restaurante","Rascal Restaurantes",332.90,"2025-12-24","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Farmácia","Granado Rio de Janeiro",148.00,"2025-12-24","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Alimentação","Casa Fernandes",160.00,"2025-12-27","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Estacionamento","HTSA Estacionamento",79.90,"2025-12-27","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Padaria / Café","Padaria V Monumento",90.00,"2025-12-27","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Padaria / Café","Paes e Doces Manhattan",14.69,"2025-12-27","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Alimentação","Isamoitokazufeira",85.00,"2025-12-27","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Serviços Digitais","Imagine Store",5.99,"2025-12-27","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Restaurante","Rodosnack Alemão",53.60,"2025-12-28","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Moda / Vestuário","Roberta Ferreira",291.50,"2025-12-29","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Farmácia","Farmabem",37.17,"2025-12-31","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Lazer / Entretenimento","120 LPF São Paulo Shopping",87.92,"2026-01-02","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Restaurante","Arco Iris Roseira",352.08,"2026-01-02","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Alimentação","Rei do Mate Shopping",7.90,"2026-01-02","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Alimentação","Chocolatria",88.10,"2026-01-02","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Restaurante","Restaurante Arco Iris",82.50,"2026-01-02","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Padaria / Café","Pati Piva",66.55,"2026-01-03","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Padaria / Café","Paes e Doces Manhattan",55.69,"2026-01-03","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Restaurante","R112 JK",180.00,"2026-01-03","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Moda / Vestuário","Osklen JK Iguatemi",150.00,"2026-01-03","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Padaria / Café","Amem Cafe",27.00,"2026-01-04","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Farmácia","Raia",101.79,"2026-01-04","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Lazer / Entretenimento","Penoparque",196.35,"2026-01-04","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Padaria / Café","Paes e Doces Manhattan",97.67,"2026-01-04","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Casa / Moradia","Kalunga Moema",32.90,"2026-01-05","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Alimentação","FDL Comércio de Chocol.",25.80,"2026-01-05","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Estacionamento","Estapar Mono Sede Santander",20.00,"2026-01-05","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Restaurante","Oval JK",51.80,"2026-01-05","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Padaria / Café","Cafe Caoc",47.36,"2026-01-06","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Restaurante","Oval JK",69.70,"2026-01-07","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Restaurante","Oval JK",45.00,"2026-01-08","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Restaurante","Torero Valese",137.85,"2026-01-09","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Padaria / Café","Paes e Doces Manhattan",98.55,"2026-01-10","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Lazer / Entretenimento","Equipe Tenorio",23.00,"2026-01-10","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Restaurante","Restaurante Pub Kei",656.00,"2026-01-10","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Padaria / Café","Paes e Doces Manhattan",23.41,"2026-01-11","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Lazer / Entretenimento","SCP Plus - Jan/26",21.01,"2026-01-12","pdf","AAdvantage *3313 Jan/26",true),
  mk("gasto","Combustível","Posto Ortega",372.43,"2026-01-12","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Padaria / Café","Paes e Doces Manhattan",57.92,"2026-01-12","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Restaurante","Rascal",164.40,"2026-01-12","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Restaurante","Oval JK",66.80,"2026-01-13","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Restaurante","LPQBR Restaurantes",54.24,"2026-01-13","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Restaurante","ADS Flamingo Restaurante",163.10,"2026-01-14","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Alimentação","FDL Comércio de Chocol.",13.90,"2026-01-14","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Restaurante","Oval JK",66.70,"2026-01-14","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Padaria / Café","Blenz Cafe",13.80,"2026-01-14","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Serviços Digitais","PKR",12.49,"2026-01-15","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Academia / Bem-estar","Lev Moema",280.00,"2026-01-15","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Restaurante","Trentino Grill",62.22,"2026-01-15","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Alimentação","2C Alimentação",25.48,"2026-01-16","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Lazer / Entretenimento","Sala VIP Piranga",617.82,"2026-01-16","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Saúde / Clínica","Clínica Daniela",1020.60,"2026-01-16","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Restaurante","Oval JK",45.00,"2026-01-16","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Estacionamento","JC Estacionamento",30.00,"2026-01-16","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Supermercado","Supermercado Vila das Flores",83.85,"2026-01-17","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Alimentação","Cristina Mieko Tagomori",24.00,"2026-01-17","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Alimentação","Comércio de Pasteis K",28.00,"2026-01-17","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Alimentação","Disk Feira",25.00,"2026-01-17","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Padaria / Café","Amem Cafe",19.50,"2026-01-18","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Restaurante","Butcher's Truck",299.22,"2026-01-18","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Padaria / Café","Paes e Doces Manhattan",108.80,"2026-01-18","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Lazer / Entretenimento","Fun Funchal",68.30,"2026-01-18","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Restaurante","Oval JK",45.00,"2026-01-19","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Alimentação","Dama Comércio de Alimentos",23.28,"2026-01-19","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Padaria / Café","Blenz Cafe",13.50,"2026-01-20","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Padaria / Café","Pati Piva",36.85,"2026-01-20","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Supermercado","Astor Comércio de Alimentos",202.84,"2026-01-20","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Padaria / Café","Paes e Doces Manhattan",50.33,"2026-01-20","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Farmácia","Raia",517.65,"2026-01-21","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Restaurante","Oval JK",45.00,"2026-01-21","pdf","AAdvantage *3313 Jan/26"),
  mk("gasto","Outros","Suzana Muniz Matos",11.00,"2026-01-21","pdf","AAdvantage *3313 Jan/26"),

  // ── Cartão Marcella *4444 — Jan/26 ──────────────────────────────────────────
  mk("gasto","Moda / Vestuário","Amazon Mktplc Bricksfun 04/04",190.17,"2025-10-07","pdf","AAdvantage *4444 Jan/26","Marcella"),
  mk("gasto","Moda / Vestuário","MNR Bling Comércio 02/02",114.00,"2025-12-14","pdf","AAdvantage *4444 Jan/26","Marcella"),
  mk("gasto","Saúde / Clínica","CAASP Sede 02/02",98.16,"2025-12-16","pdf","AAdvantage *4444 Jan/26","Marcella"),
  mk("gasto","Moda / Vestuário","PB Kids 02/02",122.44,"2025-12-17","pdf","AAdvantage *4444 Jan/26","Marcella"),
  mk("gasto","Alimentação","Bacio di Latte",99.95,"2025-12-24","pdf","AAdvantage *4444 Jan/26","Marcella"),
  mk("gasto","Padaria / Café","Blenz Cafe",6.86,"2026-01-05","pdf","AAdvantage *4444 Jan/26","Marcella"),
  mk("gasto","Farmácia","Drogasil",88.37,"2026-01-07","pdf","AAdvantage *4444 Jan/26","Marcella"),
  mk("gasto","Combustível","Posto Ortega",100.00,"2026-01-08","pdf","AAdvantage *4444 Jan/26","Marcella"),
  mk("gasto","Academia / Bem-estar","TotalPass",399.90,"2026-01-13","pdf","AAdvantage *4444 Jan/26","Marcella"),
  mk("gasto","Alimentação","Feito com Jeito",187.00,"2026-01-19","pdf","AAdvantage *4444 Jan/26","Marcella"),
  mk("gasto","Supermercado","Pão de Açúcar",281.17,"2026-01-21","pdf","AAdvantage *4444 Jan/26","Marcella"),

  // ── Cartão Virtual *5073 — Jan/26 ───────────────────────────────────────────
  mk("gasto","Transporte / Uber","Uber",22.62,"2025-12-12","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Transporte / Uber","Sem Parar",50.00,"2025-12-21","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Transporte / Uber","Uber",34.93,"2025-12-23","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Transporte / Uber","Sem Parar",50.00,"2025-12-25","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Transporte / Uber","Sem Parar",50.00,"2025-12-28","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Serviços Digitais","iFood Club",7.95,"2025-12-28","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Transporte / Uber","Sem Parar",50.00,"2025-12-30","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Serviços Digitais","Apple.com/bill",20.50,"2025-12-30","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Lazer / Entretenimento","MP Loterias Online",99.00,"2025-12-30","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Serviços Digitais","Estadão Digital",31.90,"2026-01-01","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Transporte / Uber","Sem Parar",50.00,"2026-01-02","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Restaurante","iFood - Fat Boyz Burger",85.99,"2026-01-02","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Transporte / Uber","Sem Parar",50.00,"2026-01-03","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Serviços Digitais","Produtos UOL",39.90,"2026-01-05","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Lazer / Entretenimento","MP Loterias Online",70.00,"2026-01-06","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Transporte / Uber","Uber",30.87,"2026-01-06","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Transporte / Uber","Uber",42.26,"2026-01-07","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Academia / Bem-estar","Wellhub / Gympass",539.90,"2026-01-08","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Transporte / Uber","Uber",27.42,"2026-01-08","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Lazer / Entretenimento","MP Loterias Online",70.00,"2026-01-09","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Transporte / Uber","Uber",26.57,"2026-01-09","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Lazer / Entretenimento","MP Loterias Online",106.00,"2026-01-10","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Transporte / Uber","Uber",32.85,"2026-01-12","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Transporte / Uber","Uber",31.99,"2026-01-14","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Lazer / Entretenimento","MP Loterias Online",106.00,"2026-01-17","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Transporte / Uber","Uber",50.00,"2026-01-21","pdf","AAdvantage *5073 Jan/26"),
  // Parcelamentos *5073 Jan/26
  mk("gasto","Viagem / Hospedagem","Fertility 03/05",1048.00,"2025-11-12","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Transporte / Uber","Pneus Morumbi 02/03",2232.68,"2025-11-26","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Viagem / Hospedagem","Airbnb 02/02",1532.71,"2025-11-26","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Lazer / Entretenimento","Aquário 02/02",109.50,"2025-12-02","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Educação","ClassApp 02/04",540.00,"2025-12-18","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Viagem / Hospedagem","Gol Linhas Aéreas 01/05",634.19,"2026-01-15","pdf","AAdvantage *5073 Jan/26"),
  mk("gasto","Saúde / Clínica","Clínica Daniela 01/02",1182.35,"2026-01-19","pdf","AAdvantage *5073 Jan/26"),

  // ══════════════════════════════════════════════════════════
  // SANTANDER UNIQUE *4731 — JAN/26
  // ══════════════════════════════════════════════════════════
  mk("gasto","Lazer / Entretenimento","SCP Completo - Dez/25",26.32,"2025-12-22","pdf","Unique *4731 Jan/26",true),
  mk("gasto","Seguro Residencial","Seguro Casa - Jan/26",113.92,"2026-01-02","pdf","Unique *4731 Jan/26",true),
  mk("gasto","Lazer / Entretenimento","SCP Completo - Jan/26",26.32,"2026-01-22","pdf","Unique *4731 Jan/26",true),

  // ══════════════════════════════════════════════════════════
  // FATURA AADVANTAGE BLACK *3313 — FEV/26 (venc 01/03)
  // período 24/01/26 a 23/02/26
  // ══════════════════════════════════════════════════════════
  // Parcelamentos
  mk("gasto","Moda / Vestuário","Foxton Iguatemi JK 03/03",490.66,"2025-12-14","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Alimentação","Mistral Importadora 03/03",397.59,"2025-12-17","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Moda / Vestuário","Vix Varejo - Vila Nova 02/03",282.68,"2026-01-15","pdf","AAdvantage *3313 Fev/26"),
  // Despesas
  mk("gasto","Restaurante","Oval JK",45.00,"2026-01-22","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Padaria / Café","Pati Piva",22.55,"2026-01-23","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Padaria / Café","Cafe Caoc",58.90,"2026-01-23","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Supermercado","Pão de Açúcar",22.70,"2026-01-25","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Padaria / Café","Amem Cafe",29.50,"2026-01-25","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Padaria / Café","Paes e Doces Manhattan",60.98,"2026-01-25","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Padaria / Café","Paes e Doces Manhattan",90.47,"2026-01-25","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Outros","Suzana Muniz Matos",33.00,"2026-01-26","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Enerrege Restaurante",81.90,"2026-01-26","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Boteco Varanda",180.40,"2026-01-27","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Oval JK",66.70,"2026-01-27","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Círculo Militar",86.30,"2026-01-27","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Lazer / Entretenimento","Círculo Militar - Evento",30000.00,"2026-01-27","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Timo Centrale Restaurante",147.47,"2026-01-28","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Farmácia","Raia",87.31,"2026-01-29","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Padaria / Café","Blenz Cafe",14.60,"2026-01-29","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Padaria / Café","Cafe Caoc",50.35,"2026-01-29","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Padaria / Café","Paes e Doces Manhattan",22.26,"2026-01-29","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Alimentação","Viva Mais Queijos",20.00,"2026-01-30","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Via Positano",114.40,"2026-01-30","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Boteco Varanda",651.99,"2026-02-01","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Padaria / Café","Paes e Doces Manhattan",63.40,"2026-02-01","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Padaria / Café","Paes e Doces Manhattan",21.02,"2026-02-01","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Rojo 3 Global Catering",93.70,"2026-02-02","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Padaria / Café","Paes e Doces Manhattan",20.42,"2026-02-02","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Outros","Suzana Muniz Matos",11.00,"2026-02-03","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Oval JK",45.00,"2026-02-03","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Serviços Digitais","PKR",4.99,"2026-02-03","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Oval JK",66.70,"2026-02-04","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Padaria / Café","Paes e Doces Manhattan",23.67,"2026-02-05","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Padaria / Café","Paes e Doces Manhattan",11.07,"2026-02-05","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Oval JK",45.00,"2026-02-05","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Outros","Suzana Muniz Matos",11.00,"2026-02-05","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Estacionamento","Flash Park",25.00,"2026-02-06","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Trigo Pane Pizza",228.26,"2026-02-06","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Timo Centrale Restaurante",155.56,"2026-02-06","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Alimentação","Bacio di Latte",30.95,"2026-02-06","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Casa / Moradia","Leroy Merlin",254.90,"2026-02-07","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Outros","Fabio Luiz do Amaral",15.00,"2026-02-07","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Alimentação","Disk Feira",80.00,"2026-02-07","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Outros","Tadacris",25.00,"2026-02-07","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Sabiá do Parque",73.00,"2026-02-08","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","HN21 Santos Dumont",13.60,"2026-02-08","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Supermercado","Pão de Açúcar",13.90,"2026-02-09","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Rojo 3 Global Catering",93.70,"2026-02-09","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Serviços Digitais","PKR",12.49,"2026-02-09","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Oval JK",45.00,"2026-02-10","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Outros","Suzana Muniz Matos",11.00,"2026-02-10","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Serviços Digitais","PKR",12.49,"2026-02-10","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Lazer / Entretenimento","SCP Plus - Fev/26",21.01,"2026-02-11","pdf","AAdvantage *3313 Fev/26",true),
  mk("gasto","Restaurante","Oval JK",51.80,"2026-02-11","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Serviços Digitais","PKR",4.99,"2026-02-11","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Oval JK",45.00,"2026-02-12","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Serviços Digitais","PKR",5.49,"2026-02-12","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Torero Valese",140.02,"2026-02-13","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Serviços Digitais","PKR",2.49,"2026-02-13","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Padaria / Café","Blenz Cafe",14.60,"2026-02-13","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Padaria / Café","Padaria A Trigueira",103.32,"2026-02-14","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Alimentação","Oxxo Aprazível",3.19,"2026-02-14","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Kosho",567.60,"2026-02-14","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Outros","FC Comércio",100.00,"2026-02-14","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Transporte / Uber","M&A Lava Rápido",90.00,"2026-02-14","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Guarapiranga Gastronomia",211.75,"2026-02-15","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Notorious Fish Lanche",230.52,"2026-02-15","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Guarapiranga Gastronomia",55.00,"2026-02-15","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Lazer / Entretenimento","RJ Buffet Eventos",122.04,"2026-02-16","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Boteco Varanda",53.01,"2026-02-16","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Padaria / Café","Paes e Doces Manhattan",81.79,"2026-02-17","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Lazer / Entretenimento","RJ Buffet Eventos",20.50,"2026-02-17","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Serviços Digitais","PKR",12.49,"2026-02-18","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Supermercado","Astor Comércio de Alimentos",117.52,"2026-02-18","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Padaria / Café","Paes e Doces Manhattan",61.74,"2026-02-18","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Rascal",152.32,"2026-02-19","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Outros","Suzana Muniz Matos",13.00,"2026-02-19","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Serviços Digitais","PKR",11.99,"2026-02-19","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Oval JK",69.00,"2026-02-20","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Alimentação","Valerio Hortifruti",70.00,"2026-02-21","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Alimentação","Isamoitokazufeira",20.00,"2026-02-21","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Restaurante","Zdeli Restaurante",336.74,"2026-02-21","pdf","AAdvantage *3313 Fev/26"),
  mk("gasto","Padaria / Café","Padaria A Trigueira",101.62,"2026-02-21","pdf","AAdvantage *3313 Fev/26"),

  // ── Cartão Marcella *4444 — Fev/26 ──────────────────────────────────────────
  mk("gasto","Moda / Vestuário","584 Comércio de Vestuário 01/02",110.35,"2026-01-30","pdf","AAdvantage *4444 Fev/26","Marcella"),
  mk("gasto","Combustível","Abastece Aí",347.10,"2026-01-25","pdf","AAdvantage *4444 Fev/26","Marcella"),
  mk("gasto","Casa / Moradia","MercadoLivre Produtos",369.67,"2026-01-30","pdf","AAdvantage *4444 Fev/26","Marcella"),
  mk("gasto","Lazer / Entretenimento","RJ Buffet Eventos",93.50,"2026-01-30","pdf","AAdvantage *4444 Fev/26","Marcella"),
  mk("gasto","Moda / Vestuário","Mundo Calç. São Bento",49.99,"2026-02-03","pdf","AAdvantage *4444 Fev/26","Marcella"),
  mk("gasto","Lazer / Entretenimento","Presentes Mickey",76.50,"2026-02-10","pdf","AAdvantage *4444 Fev/26","Marcella"),
  mk("gasto","Combustível","Abastece Aí",354.08,"2026-02-11","pdf","AAdvantage *4444 Fev/26","Marcella"),
  mk("gasto","Academia / Bem-estar","TotalPass",399.90,"2026-02-13","pdf","AAdvantage *4444 Fev/26","Marcella"),
  mk("gasto","Lazer / Entretenimento","SPA JK Iguatemi",30.00,"2026-02-19","pdf","AAdvantage *4444 Fev/26","Marcella"),
  mk("gasto","Padaria / Café","Blenz Cafe",6.86,"2026-02-19","pdf","AAdvantage *4444 Fev/26","Marcella"),
  mk("gasto","Combustível","Abastece Aí",376.71,"2026-02-21","pdf","AAdvantage *4444 Fev/26","Marcella"),

  // ── Cartão Virtual *5073 — Fev/26 ───────────────────────────────────────────
  mk("gasto","Transporte / Uber","Sem Parar",50.00,"2026-01-23","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Transporte / Uber","Uber",28.98,"2026-01-27","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Transporte / Uber","Uber",18.99,"2026-01-27","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Serviços Digitais","iFood Club",7.95,"2026-01-28","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Serviços Digitais","Apple.com/bill",20.50,"2026-01-30","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Transporte / Uber","Uber",25.97,"2026-01-30","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Restaurante","iFood - GPL Pizza",132.99,"2026-01-31","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Transporte / Uber","Sem Parar",50.00,"2026-01-31","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Lazer / Entretenimento","MP Loterias Online",106.00,"2026-01-31","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Restaurante","iFood - Olga Ri Alimentos",155.48,"2026-02-04","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Serviços Digitais","Produtos UOL",39.90,"2026-02-05","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Transporte / Uber","Uber",27.71,"2026-02-06","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Restaurante","iFood - Lanchonete LFY",131.98,"2026-02-07","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Estacionamento","Estapar Reserva",95.31,"2026-02-08","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Transporte / Uber","Uber",80.23,"2026-02-08","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Transporte / Uber","Uber",32.19,"2026-02-09","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Transporte / Uber","Uber",32.85,"2026-02-13","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Transporte / Uber","Uber",38.04,"2026-02-13","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Transporte / Uber","Uber DL UberRides",23.98,"2026-02-14","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Transporte / Uber","Uber",73.51,"2026-02-14","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Restaurante","iFood - Fat Boyz Burger",89.99,"2026-02-17","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Transporte / Uber","Uber",22.92,"2026-02-20","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Transporte / Uber","Uber",24.56,"2026-02-20","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Transporte / Uber","Sem Parar",50.00,"2026-02-20","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Lazer / Entretenimento","MP Loterias Online",99.00,"2026-02-21","pdf","AAdvantage *5073 Fev/26"),
  // Parcelamentos *5073 Fev/26
  mk("gasto","Lazer / Entretenimento","Eventim 04/04",223.75,"2025-11-11","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Saúde / Clínica","Fertility 04/05",1048.00,"2025-11-12","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Transporte / Uber","Pneus Morumbi 03/03",2232.66,"2025-11-26","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Educação","ClassApp 03/04",540.00,"2025-12-18","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Viagem / Hospedagem","Gol Linhas Aéreas 02/05",634.18,"2026-01-15","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Saúde / Clínica","Clínica Daniela 02/02",1182.35,"2026-01-19","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Viagem / Hospedagem","Gol Linhas Aéreas 01/02",171.14,"2026-02-10","pdf","AAdvantage *5073 Fev/26"),
  mk("gasto","Viagem / Hospedagem","Gol Linhas Aéreas 01/03",217.52,"2026-02-10","pdf","AAdvantage *5073 Fev/26"),

  // ══════════════════════════════════════════════════════════
  // SANTANDER UNIQUE *4731 — FEV/26
  // ══════════════════════════════════════════════════════════
  mk("gasto","Seguro Residencial","Seguro Casa - Fev/26",113.92,"2026-02-02","pdf","Unique *4731 Fev/26",true),
];

// ─── Theme ──────────────────────────────────────────────────────────────────
const T={bg:"#0c0e14",surface:"#13161f",card:"#191d2a",border:"#232840",text:"#e4e8f5",muted:"#6b728f",accent:"#4d7cf6",green:"#26c67a",red:"#f0556a",blue:"#4d7cf6",amber:"#f0a035",purple:"#9b6ff7",greenBg:"rgba(38,198,122,.1)",redBg:"rgba(240,85,106,.1)",blueBg:"rgba(77,124,246,.1)",amberBg:"rgba(240,160,53,.1)"};

const lbl={fontSize:11,fontWeight:700,color:T.muted,letterSpacing:.7,textTransform:"uppercase",display:"block",marginBottom:5};
const inp={background:T.surface,border:`1.5px solid ${T.border}`,borderRadius:10,padding:"9px 13px",fontSize:13,color:T.text,outline:"none",width:"100%",boxSizing:"border-box",fontFamily:"'Sora',sans-serif"};
const sel={background:T.surface,border:`1.5px solid ${T.border}`,borderRadius:10,padding:"9px 13px",fontSize:13,color:T.text,outline:"none",cursor:"pointer",fontFamily:"'Sora',sans-serif",width:"100%"};
const btnP={background:T.accent,color:"#fff",border:"none",borderRadius:9,padding:"9px 18px",cursor:"pointer",fontSize:13,fontWeight:700,fontFamily:"'Sora',sans-serif"};
const btnO={background:"transparent",color:T.muted,border:`1.5px solid ${T.border}`,borderRadius:9,padding:"9px 18px",cursor:"pointer",fontSize:13,fontWeight:600,fontFamily:"'Sora',sans-serif"};
const btnS={borderRadius:8,padding:"6px 12px",cursor:"pointer",fontSize:12,fontWeight:600,fontFamily:"'Sora',sans-serif",border:"none"};

const Pill=({tipo})=>{const m={receita:{c:T.green,bg:T.greenBg,l:"Receita"},gasto:{c:T.red,bg:T.redBg,l:"Gasto"},investimento:{c:T.blue,bg:T.blueBg,l:"Invest."}}[tipo];return<span style={{background:m.bg,color:m.c,borderRadius:20,padding:"2px 9px",fontSize:10,fontWeight:700,letterSpacing:.5}}>{m.l}</span>;};
const Bar=({pct,color})=><div style={{background:"rgba(255,255,255,.06)",borderRadius:99,height:6,overflow:"hidden",marginTop:4}}><div style={{height:"100%",background:color,borderRadius:99,width:`${Math.min(Math.abs(pct||0),100)}%`,transition:"width .8s ease"}}/></div>;
const Overlay=({children})=><div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.75)",zIndex:1000,display:"flex",alignItems:"center",justifyContent:"center",overflowY:"auto",padding:16}}>{children}</div>;

function FormModal({form,setForm,editId,categories,applyRules,onSave,onClose}){
  return(<Overlay><div style={{background:T.card,border:`1px solid ${T.border}`,borderRadius:20,padding:28,width:500,maxWidth:"95vw"}}>
    <div style={{fontSize:17,fontWeight:800,marginBottom:20}}>{editId?"Editar":"Novo Lançamento"}</div>
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:12}}>
      <div><label style={lbl}>Tipo</label><select style={sel} value={form.tipo} onChange={e=>setForm(f=>({...f,tipo:e.target.value,categoria:(categories[e.target.value]||[])[0]||""}))}>
        <option value="receita">Receita</option><option value="gasto">Gasto</option><option value="investimento">Investimento</option></select></div>
      <div><label style={lbl}>Categoria</label><select style={sel} value={form.categoria} onChange={e=>setForm(f=>({...f,categoria:e.target.value}))}>
        {(categories[form.tipo]||[]).map(c=><option key={c}>{c}</option>)}</select></div>
    </div>
    <div style={{marginBottom:12}}><label style={lbl}>Descrição</label>
      <input style={inp} value={form.descricao} onChange={e=>{const v=e.target.value;const r=applyRules(v);setForm(f=>({...f,descricao:v,...(r&&!editId?r:{})}));}}/>
      {applyRules(form.descricao)&&<div style={{fontSize:10,color:T.amber,marginTop:3}}>⚡ Regra aplicada → {applyRules(form.descricao)?.categoria}</div>}
    </div>
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:12}}>
      <div><label style={lbl}>Valor (R$)</label><input style={inp} type="number" step="0.01" value={form.valor} onChange={e=>setForm(f=>({...f,valor:e.target.value}))}/></div>
      <div><label style={lbl}>Data</label><input style={inp} type="date" value={form.data} onChange={e=>setForm(f=>({...f,data:e.target.value}))}/></div>
    </div>
    <div style={{marginBottom:12}}><label style={lbl}>Fonte / Documento</label><input style={inp} value={form.fonte||""} onChange={e=>setForm(f=>({...f,fonte:e.target.value}))}/></div>
    <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:20,padding:"10px 12px",background:T.surface,borderRadius:10}}>
      <input type="checkbox" id="rec" checked={form.recorrente||false} onChange={e=>setForm(f=>({...f,recorrente:e.target.checked}))} style={{accentColor:T.accent,width:16,height:16}}/>
      <label htmlFor="rec" style={{fontSize:13,fontWeight:600,cursor:"pointer"}}>Recorrente</label>
      {form.recorrente&&<select style={{...sel,flex:1}} value={form.recorrencia||"mensal"} onChange={e=>setForm(f=>({...f,recorrencia:e.target.value}))}>
        <option value="mensal">Mensal</option><option value="semanal">Semanal</option><option value="anual">Anual</option></select>}
    </div>
    <div style={{display:"flex",gap:10,justifyContent:"flex-end"}}>
      <button style={btnO} onClick={onClose}>Cancelar</button>
      <button style={btnP} onClick={onSave}>{editId?"Salvar":"Adicionar"}</button>
    </div>
  </div></Overlay>);
}

function ReclassifyModal({tx,allTx,categories,onConfirm,onClose}){
  const [newTipo,setNewTipo]=useState(tx.tipo);
  const [newCat,setNewCat]=useState(tx.categoria);
  const [scope,setScope]=useState("single");
  const sameDesc=allTx.filter(t=>t.id!==tx.id&&t.descricao===tx.descricao).length;
  return(<Overlay><div style={{background:T.card,border:`1px solid ${T.border}`,borderRadius:20,padding:28,width:460,maxWidth:"95vw"}}>
    <div style={{fontSize:17,fontWeight:800,marginBottom:4}}>⇄ Reclassificar</div>
    <div style={{fontSize:11,color:T.muted,marginBottom:20,fontFamily:"'JetBrains Mono',monospace"}}>{tx.descricao} · {fmt(tx.valor)}</div>
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:20}}>
      <div><label style={lbl}>Novo Tipo</label><select style={sel} value={newTipo} onChange={e=>{setNewTipo(e.target.value);setNewCat((categories[e.target.value]||[])[0]||"");}}>
        <option value="receita">Receita</option><option value="gasto">Gasto</option><option value="investimento">Investimento</option></select></div>
      <div><label style={lbl}>Nova Categoria</label><select style={sel} value={newCat} onChange={e=>setNewCat(e.target.value)}>
        {(categories[newTipo]||[]).map(c=><option key={c}>{c}</option>)}</select></div>
    </div>
    {[{v:"single",l:"Apenas este lançamento"},{v:"desc",l:`Todos "${tx.descricao.slice(0,25)}..." (${sameDesc} outros)`,disabled:sameDesc===0}].map(op=>(
      <label key={op.v} style={{display:"flex",gap:10,padding:"10px 12px",borderRadius:10,marginBottom:6,cursor:op.disabled?"not-allowed":"pointer",background:scope===op.v?"rgba(77,124,246,.12)":T.surface,border:`1.5px solid ${scope===op.v?T.accent:T.border}`,opacity:op.disabled?.4:1}}>
        <input type="radio" value={op.v} checked={scope===op.v} disabled={op.disabled} onChange={()=>setScope(op.v)} style={{accentColor:T.accent}}/>
        <span style={{fontSize:13,fontWeight:600}}>{op.l}</span>
      </label>
    ))}
    <div style={{display:"flex",gap:10,justifyContent:"flex-end",marginTop:20}}>
      <button style={btnO} onClick={onClose}>Cancelar</button>
      <button style={btnP} onClick={()=>onConfirm({newTipo,newCat,scope,tx})}>Confirmar</button>
    </div>
  </div></Overlay>);
}

export default function App(){
  const [txs,setTxs]=useState(()=>{try{const s=localStorage.getItem("financas_txs");return s?JSON.parse(s):SEED;}catch{return SEED;}});
  const [categories,setCategories]=useState(DEFAULT_CATS);
  const [rules,setRules]=useState([
    {id:1,keyword:"Porto Seguro Auto",tipo:"gasto",categoria:"Seguro Veículo"},
    {id:2,keyword:"PGBL",tipo:"investimento",categoria:"PGBL / Previdência"},
    {id:3,keyword:"Salário",tipo:"receita",categoria:"Salário Líquido"},
    {id:4,keyword:"PLR",tipo:"receita",categoria:"PLR / Remuneração Variável"},
    {id:5,keyword:"Assist. Médica",tipo:"gasto",categoria:"Plano de Saúde"},
    {id:6,keyword:"Uber",tipo:"gasto",categoria:"Transporte / Uber"},
    {id:7,keyword:"Sem Parar",tipo:"gasto",categoria:"Transporte / Uber"},
    {id:8,keyword:"Posto",tipo:"gasto",categoria:"Combustível"},
    {id:9,keyword:"Raia",tipo:"gasto",categoria:"Farmácia"},
    {id:10,keyword:"Farmácia",tipo:"gasto",categoria:"Farmácia"},
    {id:11,keyword:"Farmabem",tipo:"gasto",categoria:"Farmácia"},
    {id:12,keyword:"iFood",tipo:"gasto",categoria:"Restaurante"},
    {id:13,keyword:"Anuidade",tipo:"gasto",categoria:"Anuidade Cartão"},
    {id:14,keyword:"Seguro Casa",tipo:"gasto",categoria:"Seguro Residencial"},
    {id:15,keyword:"Gympass",tipo:"gasto",categoria:"Academia / Bem-estar"},
    {id:16,keyword:"TotalPass",tipo:"gasto",categoria:"Academia / Bem-estar"},
    {id:17,keyword:"Apple",tipo:"gasto",categoria:"Serviços Digitais"},
    {id:18,keyword:"Estapar",tipo:"gasto",categoria:"Estacionamento"},
    {id:19,keyword:"Gol Linhas",tipo:"gasto",categoria:"Viagem / Hospedagem"},
    {id:20,keyword:"Airbnb",tipo:"gasto",categoria:"Viagem / Hospedagem"},
  ]);
  const [tab,setTab]=useState("dashboard");
  const [modal,setModal]=useState(null);
  const [selectedTx,setSelectedTx]=useState(null);
  const [uploading,setUploading]=useState(false);
  const [uploadMsg,setUploadMsg]=useState("");
  const [uploadLog,setUploadLog]=useState([]);
  const [form,setForm]=useState({tipo:"gasto",categoria:"Alimentação",descricao:"",valor:"",data:today(),origem:"manual",recorrente:false,recorrencia:"mensal",fonte:""});
  const [editId,setEditId]=useState(null);
  const [filterTipo,setFilterTipo]=useState("todos");
  const [filterMes,setFilterMes]=useState("todos");
  const [filterCat,setFilterCat]=useState("todas");
  const [filterFonte,setFilterFonte]=useState("todas");
  const [searchQ,setSearchQ]=useState("");
  const [histMode,setHistMode]=useState("mensal");
  const [histMetric,setHistMetric]=useState("gasto");
  const [aiChat,setAiChat]=useState([]);
  const [chatInput,setChatInput]=useState("");
  const [chatLoading,setChatLoading]=useState(false);
  const fileRef=useRef();
  const chatRef=useRef();

  const applyRules=useCallback(desc=>{
    for(const r of rules){if(desc.toLowerCase().includes(r.keyword.toLowerCase()))return{tipo:r.tipo,categoria:r.categoria};}
    return null;
  },[rules]);

  const totals=useMemo(()=>({
    receita:txs.filter(t=>t.tipo==="receita").reduce((a,b)=>a+b.valor,0),
    gasto:txs.filter(t=>t.tipo==="gasto").reduce((a,b)=>a+b.valor,0),
    invest:txs.filter(t=>t.tipo==="investimento").reduce((a,b)=>a+b.valor,0),
  }),[txs]);
  const saldo=totals.receita-totals.gasto-totals.invest;

  useEffect(()=>{try{localStorage.setItem("financas_txs",JSON.stringify(txs));}catch(e){}},[txs]);
  const allCats=useMemo(()=>[...new Set(txs.map(t=>t.categoria))].sort(),[txs]);
  const allFontes=useMemo(()=>[...new Set(txs.map(t=>t.fonte).filter(Boolean))].sort(),[txs]);

  const filtered=useMemo(()=>txs.filter(t=>{
    const tipoOk=filterTipo==="todos"||t.tipo===filterTipo;
    const mesOk=filterMes==="todos"||t.data.slice(5,7)===filterMes;
    const catOk=filterCat==="todas"||t.categoria===filterCat;
    const fonteOk=filterFonte==="todas"||t.fonte===filterFonte;
    const qOk=!searchQ||t.descricao.toLowerCase().includes(searchQ.toLowerCase())||t.categoria.toLowerCase().includes(searchQ.toLowerCase())||(t.fonte||"").toLowerCase().includes(searchQ.toLowerCase());
    return tipoOk&&mesOk&&catOk&&fonteOk&&qOk;
  }).sort((a,b)=>b.data.localeCompare(a.data)),[txs,filterTipo,filterMes,filterCat,filterFonte,searchQ]);

  const gastosCat=useMemo(()=>{const r={};txs.filter(t=>t.tipo==="gasto").forEach(t=>{r[t.categoria]=(r[t.categoria]||0)+t.valor;});return Object.entries(r).sort((a,b)=>b[1]-a[1]);},[txs]);

  const histData=useMemo(()=>{
    const b={};
    txs.forEach(t=>{
      const k=histMode==="mensal"?monthKey(t.data):histMode==="trimestral"?quarterKey(t.data):t.data.slice(0,4);
      if(!b[k])b[k]={key:k,receita:0,gasto:0,investimento:0};
      b[k][t.tipo]=(b[k][t.tipo]||0)+t.valor;
    });
    return Object.values(b).sort((a,x)=>a.key.localeCompare(x.key)).map(b2=>({...b2,saldo:b2.receita-b2.gasto-b2.investimento}));
  },[txs,histMode]);

  const keyLabel=k=>histMode==="mensal"?monthLabel(k):histMode==="trimestral"?quarterLabel(k):k;
  const metricColor={receita:T.green,gasto:T.red,investimento:T.blue,saldo:T.purple}[histMetric];
  const maxVal=Math.max(...histData.map(b=>Math.abs(b[histMetric])),1);

  const saveForm=()=>{
    if(!form.descricao||!form.valor)return;
    const rule=applyRules(form.descricao);
    const entry={...form,valor:parseFloat(form.valor),id:editId||Date.now(),...(rule&&!editId?rule:{})};
    if(editId)setTxs(ts=>ts.map(t=>t.id===editId?entry:t));
    else setTxs(ts=>[...ts,entry]);
    setEditId(null);setModal(null);
    setForm({tipo:"gasto",categoria:"Alimentação",descricao:"",valor:"",data:today(),origem:"manual",recorrente:false,recorrencia:"mensal",fonte:""});
  };

  const handleEdit=t=>{setForm({...t,valor:String(t.valor)});setEditId(t.id);setModal("form");};
  const handleDelete=id=>setTxs(ts=>ts.filter(t=>t.id!==id));
  const doReclassify=({newTipo,newCat,scope,tx})=>{
    setTxs(ts=>ts.map(t=>{
      if(scope==="single"&&t.id===tx.id)return{...t,tipo:newTipo,categoria:newCat};
      if(scope==="desc"&&t.descricao===tx.descricao)return{...t,tipo:newTipo,categoria:newCat};
      return t;
    }));
    setModal(null);setSelectedTx(null);
  };

  const handleUpload=async e=>{
    const file=e.target.files[0];if(!file)return;
    setUploading(true);setUploadMsg("Lendo PDF com IA…");setUploadLog([]);
    try{
      const base64=await new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result.split(",")[1]);r.onerror=rej;r.readAsDataURL(file);});
      const catsList=Object.entries(categories).map(([t,cs])=>`${t}: ${cs.join(", ")}`).join(" | ");
      const rulesList=rules.map(r=>`"${r.keyword}"→${r.tipo}/${r.categoria}`).join(", ");
      const res=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:4000,
          messages:[{role:"user",content:[
            {type:"document",source:{type:"base64",media_type:"application/pdf",data:base64}},
            {type:"text",text:`Extraia TODOS os lançamentos financeiros individuais deste documento brasileiro.

TIPOS DE DOCUMENTO:
- Fatura Santander (AAdvantage/Unique): extraia cada compra. Ignore linhas de pagamento (DEB AUTOM). Para parcelamentos, registre a parcela atual. Infira o ano pelo período da fatura.
- Holerite Santander MENSAL: apenas "Total líquido" como receita "Salário Líquido". PGBL como investimento. Assistência médica como gasto.
- Holerite REMUNERAÇÃO VARIAVEL: apenas "Total líquido" como receita "PLR / Remuneração Variável".
- Extrato bancário/investimentos: extraia entradas e saídas.

REGRAS: ${rulesList}
CATEGORIAS: ${catsList}

Responda APENAS JSON sem markdown:
{"tipo_documento":"string","periodo":"MM/YYYY","transacoes":[{"tipo":"receita|gasto|investimento","categoria":"string","descricao":"string","valor":0.00,"data":"YYYY-MM-DD","recorrente":false,"fonte":"nome doc","titular":"Vitor|Marcella"}]}`}
          ]}]
        })
      });
      const d=await res.json();
      const text=d.content.map(c=>c.text||"").join("");
      const parsed=JSON.parse(text.replace(/```json|```/g,"").trim());
      const novas=parsed.transacoes.map(t=>({...t,id:Date.now()+Math.random(),origem:"pdf"}));
      setTxs(ts=>[...ts,...novas]);
      setUploadLog(novas.map(t=>`${t.data} · ${t.descricao} · ${fmt(t.valor)}`));
      setUploadMsg(`✅ ${novas.length} lançamento(s) importado(s) — ${parsed.tipo_documento} ${parsed.periodo||""}`);
      setTab("transacoes");
    }catch(err){setUploadMsg("❌ Erro ao processar. Tente novamente.");}
    setUploading(false);e.target.value="";
  };

  const sendChat=async()=>{
    if(!chatInput.trim())return;
    const userMsg=chatInput.trim();setChatInput("");
    setAiChat(c=>[...c,{role:"user",text:userMsg}]);setChatLoading(true);
    const topGastos=gastosCat.slice(0,8).map(([c,v])=>`${c}:${fmt(v)}`).join(", ");
    const ctx=`Dados reais - Vitor Granero, Product Manager Santander SP.
Receitas: ${fmt(totals.receita)} | Gastos: ${fmt(totals.gasto)} | Investimentos: ${fmt(totals.invest)} | Saldo: ${fmt(saldo)}
Total lançamentos: ${txs.length} (de PDFs reais: holerites Jan-Fev/26, faturas AAdvantage Black *3313 e *5073 Jan-Fev/26, Unique *4731 Jan-Fev/26, Porto Bank Jan-Mar/26)
PLR/Bônus Fev/26: R$573.031,42 (extraordinário)
Fatura AAdvantage Fev/26: R$47.445,78 (inclui R$30.000 Círculo Militar - provável evento/festa)
Cartão adicional Marcella: gastos com combustível, farmácia, academia, roupa
Top categorias de gasto: ${topGastos}
Histórico: ${histData.map(b=>`${keyLabel(b.key)}[rec:${fmtShort(b.receita)},gasto:${fmtShort(b.gasto)},saldo:${fmtShort(b.saldo)}]`).join(" ")}`;
    try{
      const r=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1500,
          system:`Você é consultor financeiro pessoal especializado em finanças de alta renda no Brasil. Use os dados reais do usuário. Seja direto, prático e use os números reais. Contexto: ${ctx}`,
          messages:aiChat.concat([{role:"user",text:userMsg}]).map(m=>({role:m.role,content:m.text}))
        })
      });
      const d2=await r.json();
      setAiChat(c=>[...c,{role:"assistant",text:d2.content.map(x=>x.text||"").join("")}]);
    }catch{setAiChat(c=>[...c,{role:"assistant",text:"Erro de conexão. Tente novamente."}]);}
    setChatLoading(false);
    setTimeout(()=>chatRef.current?.scrollTo(0,99999),100);
  };

  const NAVS=[{id:"dashboard",icon:"◈",label:"Dashboard"},{id:"transacoes",icon:"≡",label:"Transações"},{id:"historico",icon:"◷",label:"Histórico"},{id:"upload",icon:"↑",label:"Importar PDF"},{id:"consultor",icon:"✦",label:"Consultor IA"}];
  const card={background:T.card,border:`1px solid ${T.border}`,borderRadius:16,padding:20};

  return(<>
    <link href={FONT} rel="stylesheet"/>
    <style>{`*{box-sizing:border-box;margin:0;padding:0;}body{background:${T.bg};}::-webkit-scrollbar{width:4px;height:4px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:${T.border};border-radius:99px}input,select,button{font-family:'Sora',sans-serif;}input::placeholder{color:${T.muted}}select option{background:${T.surface}}`}</style>

    <div style={{fontFamily:"'Sora',sans-serif",minHeight:"100vh",background:T.bg,color:T.text,display:"flex"}}>

      {/* Sidebar */}
      <aside style={{width:200,background:T.surface,borderRight:`1px solid ${T.border}`,display:"flex",flexDirection:"column",position:"fixed",top:0,left:0,bottom:0,zIndex:50}}>
        <div style={{padding:"22px 20px 18px",borderBottom:`1px solid ${T.border}`}}>
          <div style={{fontSize:15,fontWeight:800,letterSpacing:-.5}}>💰 FinançasFam</div>
          <div style={{fontSize:9,color:T.muted,marginTop:2,letterSpacing:.8,textTransform:"uppercase"}}>Vitor Granero</div>
        </div>
        <nav style={{padding:"14px 10px",flex:1}}>
          {NAVS.map(n=>(<div key={n.id} onClick={()=>setTab(n.id)} style={{display:"flex",alignItems:"center",gap:10,padding:"9px 12px",borderRadius:10,marginBottom:2,cursor:"pointer",background:tab===n.id?"rgba(77,124,246,.15)":"transparent",color:tab===n.id?T.accent:T.muted,fontWeight:tab===n.id?700:400,fontSize:13,transition:"all .15s"}}>
            <span style={{fontSize:15,fontFamily:"monospace"}}>{n.icon}</span>{n.label}
          </div>))}
        </nav>
        <div style={{padding:"14px 18px",borderTop:`1px solid ${T.border}`}}>
          <div style={{fontSize:9,color:T.muted,letterSpacing:.7,textTransform:"uppercase"}}>Saldo Líquido</div>
          <div style={{fontSize:18,fontWeight:800,color:saldo>=0?T.green:T.red,marginTop:3,fontFamily:"'JetBrains Mono',monospace"}}>{fmtShort(saldo)}</div>
          <div style={{fontSize:9,color:T.muted,marginTop:2}}>{txs.length} lançamentos</div>
        </div>
      </aside>

      <main style={{marginLeft:200,flex:1,padding:24,minHeight:"100vh"}}>

        {/* ─── DASHBOARD ─── */}
        {tab==="dashboard"&&<>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
            <h1 style={{fontSize:22,fontWeight:800,letterSpacing:-1}}>Dashboard</h1>
            <button style={{...btnP,...btnS,padding:"8px 14px"}} onClick={()=>{setEditId(null);setForm({tipo:"gasto",categoria:"Alimentação",descricao:"",valor:"",data:today(),origem:"manual",recorrente:false,recorrencia:"mensal",fonte:""});setModal("form");}}>+ Lançamento</button>
          </div>

          {/* KPIs */}
          <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:14}}>
            {[{label:"Receitas Totais",val:totals.receita,color:T.green,icon:"↑",sub:`${txs.filter(t=>t.tipo==="receita").length} lançamentos`},
              {label:"Gastos Totais",val:totals.gasto,color:T.red,icon:"↓",sub:`${txs.filter(t=>t.tipo==="gasto").length} lançamentos`},
              {label:"Investimentos",val:totals.invest,color:T.blue,icon:"◈",sub:`${txs.filter(t=>t.tipo==="investimento").length} lançamentos`},
              {label:"Saldo Livre",val:saldo,color:saldo>=0?T.purple:T.red,icon:"◉",sub:saldo>=0?"Positivo ✓":"Atenção ⚠"},
            ].map((k,i)=>(<div key={i} style={card}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:8}}>
                <span style={{fontSize:10,fontWeight:700,color:T.muted,textTransform:"uppercase",letterSpacing:.7}}>{k.label}</span>
                <span style={{fontSize:20,color:k.color,opacity:.7}}>{k.icon}</span>
              </div>
              <div style={{fontSize:20,fontWeight:800,color:k.color,fontFamily:"'JetBrains Mono',monospace"}}>{fmtShort(k.val)}</div>
              <div style={{fontSize:10,color:T.muted,marginTop:6}}>{k.sub}</div>
            </div>))}
          </div>

          {/* Alertas */}
          <div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:14}}>
            {txs.some(t=>t.categoria==="PLR / Remuneração Variável")&&<div style={{background:"rgba(155,111,247,.1)",border:`1px solid rgba(155,111,247,.3)`,borderRadius:12,padding:"10px 16px",display:"flex",alignItems:"center",gap:10}}>
              <span style={{fontSize:18}}>🎯</span>
              <span style={{fontSize:12}}><span style={{fontWeight:700,color:T.purple}}>PLR + Bônus Fev/26: </span><span style={{color:T.muted}}>R$573.031,42 creditados — considere destinar boa parte a investimentos e quitação de parcelados.</span></span>
            </div>}
            {txs.some(t=>t.descricao.includes("Círculo Militar"))&&<div style={{background:T.amberBg,border:`1px solid rgba(240,160,53,.3)`,borderRadius:12,padding:"10px 16px",display:"flex",alignItems:"center",gap:10}}>
              <span style={{fontSize:18}}>⚠️</span>
              <span style={{fontSize:12}}><span style={{fontWeight:700,color:T.amber}}>Gasto atípico: </span><span style={{color:T.muted}}>Círculo Militar R$30.000 em Jan/26 — verifique a categoria e reclassifique se necessário.</span></span>
            </div>}
          </div>

          <div style={{display:"grid",gridTemplateColumns:"1.6fr 1fr",gap:12,marginBottom:12}}>
            <div style={card}>
              <div style={{fontSize:13,fontWeight:700,marginBottom:12}}>Últimos Lançamentos</div>
              <table style={{width:"100%",borderCollapse:"collapse"}}>
                <tbody>{txs.slice().sort((a,b)=>b.data.localeCompare(a.data)).slice(0,10).map(t=>(
                  <tr key={t.id} style={{borderBottom:`1px solid ${T.border}`}}>
                    <td style={{padding:"6px 0",width:72,fontSize:9,color:T.muted,fontFamily:"'JetBrains Mono',monospace"}}>{t.data.slice(5).replace("-","/")} /{t.data.slice(2,4)}</td>
                    <td style={{padding:"6px 8px"}}><div style={{fontSize:11,fontWeight:600,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",maxWidth:200}}>{t.descricao}</div><div style={{fontSize:9,color:T.muted}}>{t.categoria}</div></td>
                    <td style={{padding:"6px 0"}}><Pill tipo={t.tipo}/></td>
                    <td style={{textAlign:"right",padding:"6px 0",fontFamily:"'JetBrains Mono',monospace",fontWeight:700,fontSize:11,color:t.tipo==="receita"?T.green:t.tipo==="investimento"?T.blue:T.red,whiteSpace:"nowrap"}}>
                      {t.tipo==="receita"?"+":"-"}{fmtShort(t.valor)}
                    </td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
            <div style={card}>
              <div style={{fontSize:13,fontWeight:700,marginBottom:12}}>Top Gastos por Categoria</div>
              {gastosCat.slice(0,8).map(([cat,val])=>(<div key={cat} style={{marginBottom:8}}>
                <div style={{display:"flex",justifyContent:"space-between",fontSize:11}}>
                  <span style={{fontWeight:600}}>{cat}</span>
                  <span style={{fontWeight:700,color:T.red,fontFamily:"'JetBrains Mono',monospace"}}>{fmt(val)}</span>
                </div>
                <Bar pct={totals.gasto>0?(val/totals.gasto)*100:0} color={T.red}/>
                <div style={{fontSize:9,color:T.muted,marginTop:1}}>{totals.gasto>0?((val/totals.gasto)*100).toFixed(1):0}%</div>
              </div>))}
            </div>
          </div>

          <div style={card}>
            <div style={{fontSize:13,fontWeight:700,marginBottom:14}}>Saúde Financeira</div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:16}}>
              {[
                {label:"Taxa Investimento",val:totals.receita>0?(totals.invest/totals.receita)*100:0,target:20,color:T.blue,dir:"≥",ok:totals.receita>0&&(totals.invest/totals.receita)*100>=20},
                {label:"Comprometimento",val:totals.receita>0?(totals.gasto/totals.receita)*100:0,target:70,color:T.red,dir:"≤",ok:totals.receita>0&&(totals.gasto/totals.receita)*100<=70},
                {label:"Margem Livre",val:totals.receita>0?(Math.max(saldo,0)/totals.receita)*100:0,target:10,color:T.green,dir:"≥",ok:saldo>0},
                {label:"Índice Liquidez",val:totals.gasto>0?saldo/totals.gasto:0,target:1,color:T.purple,dir:"≥",ok:saldo/Math.max(totals.gasto,1)>=1,unit:"x"},
              ].map((item,i)=>(<div key={i}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:4,fontSize:12}}>
                  <span style={{fontWeight:600}}>{item.label}</span>
                  <span style={{fontWeight:800,color:item.ok?item.color:T.red,fontFamily:"'JetBrains Mono',monospace"}}>{item.val.toFixed(1)}{item.unit||"%"}</span>
                </div>
                <Bar pct={Math.min(Math.abs(item.val),100)} color={item.ok?item.color:T.red}/>
                <div style={{fontSize:9,color:T.muted,marginTop:3,display:"flex",justifyContent:"space-between"}}>
                  <span>Meta: {item.dir}{item.target}{item.unit||"%"}</span>
                  <span style={{color:item.ok?T.green:T.red}}>{item.ok?"✓ OK":"✗ Atenção"}</span>
                </div>
              </div>))}
            </div>
          </div>
        </>}

        {/* ─── TRANSAÇÕES ─── */}
        {tab==="transacoes"&&<>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:18}}>
            <h1 style={{fontSize:22,fontWeight:800,letterSpacing:-1}}>Transações <span style={{fontSize:14,color:T.muted,fontWeight:400}}>({filtered.length}/{txs.length})</span></h1>
            <button style={{...btnP,...btnS,padding:"8px 14px"}} onClick={()=>{setEditId(null);setForm({tipo:"gasto",categoria:"Alimentação",descricao:"",valor:"",data:today(),origem:"manual",recorrente:false,recorrencia:"mensal",fonte:""});setModal("form");}}>+ Novo</button>
          </div>
          <div style={{...card,marginBottom:12}}>
            <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
              <input style={{...inp,flex:3,minWidth:160}} placeholder="🔍 Buscar..." value={searchQ} onChange={e=>setSearchQ(e.target.value)}/>
              <select style={{...sel,flex:1,minWidth:100}} value={filterTipo} onChange={e=>setFilterTipo(e.target.value)}>
                <option value="todos">Todos os tipos</option><option value="receita">Receitas</option><option value="gasto">Gastos</option><option value="investimento">Investimentos</option></select>
              <select style={{...sel,flex:1,minWidth:90}} value={filterMes} onChange={e=>setFilterMes(e.target.value)}>
                <option value="todos">Todos os meses</option>
                {Array.from({length:12},(_,i)=><option key={i} value={String(i+1).padStart(2,"0")}>{MONTH_NAMES[i]}</option>)}</select>
              <select style={{...sel,flex:1.5,minWidth:130}} value={filterCat} onChange={e=>setFilterCat(e.target.value)}>
                <option value="todas">Todas as categorias</option>
                {allCats.map(c=><option key={c}>{c}</option>)}</select>
              <select style={{...sel,flex:1.5,minWidth:130}} value={filterFonte} onChange={e=>setFilterFonte(e.target.value)}>
                <option value="todas">Todas as fontes</option>
                {allFontes.map(f=><option key={f}>{f}</option>)}</select>
            </div>
          </div>
          <div style={card}>
            <div style={{overflowX:"auto"}}>
              <table style={{width:"100%",borderCollapse:"collapse",minWidth:700}}>
                <thead><tr>{["Data","Descrição","Categoria","Tipo","Fonte","Valor",""].map(h=>(
                  <th key={h} style={{textAlign:h==="Valor"?"right":"left",fontSize:9,fontWeight:700,color:T.muted,textTransform:"uppercase",letterSpacing:.7,paddingBottom:10,borderBottom:`1px solid ${T.border}`,padding:"0 6px 10px"}}>{h}</th>
                ))}</tr></thead>
                <tbody>{filtered.map(t=>(
                  <tr key={t.id} style={{borderBottom:`1px solid ${T.border}`}}>
                    <td style={{padding:"7px 6px",fontSize:10,color:T.muted,fontFamily:"'JetBrains Mono',monospace",whiteSpace:"nowrap"}}>{t.data}</td>
                    <td style={{padding:"7px 6px",maxWidth:200}}>
                      <div style={{fontSize:11,fontWeight:600,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{t.descricao}</div>
                      <div style={{fontSize:9,color:T.muted}}>{t.titular&&t.titular!=="Vitor"&&<span style={{color:T.purple,marginRight:4}}>👤 {t.titular}</span>}{t.recorrente&&<span style={{color:T.amber}}>↻ {t.recorrencia}</span>}</div>
                    </td>
                    <td style={{padding:"7px 6px",fontSize:10,color:T.muted,whiteSpace:"nowrap"}}>{t.categoria}</td>
                    <td style={{padding:"7px 6px"}}><Pill tipo={t.tipo}/></td>
                    <td style={{padding:"7px 6px",fontSize:9,color:T.muted,maxWidth:130,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{t.fonte}</td>
                    <td style={{textAlign:"right",padding:"7px 6px",fontWeight:700,fontFamily:"'JetBrains Mono',monospace",fontSize:11,color:t.tipo==="receita"?T.green:t.tipo==="investimento"?T.blue:T.red,whiteSpace:"nowrap"}}>
                      {t.tipo==="receita"?"+":"-"}{fmt(t.valor)}</td>
                    <td style={{padding:"7px 0 7px 6px"}}>
                      <div style={{display:"flex",gap:3}}>
                        <button title="Reclassificar" style={{...btnS,background:T.amberBg,color:T.amber,padding:"3px 7px",fontSize:11}} onClick={()=>{setSelectedTx(t);setModal("reclassify");}}>⇄</button>
                        <button title="Editar" style={{...btnS,background:T.surface,color:T.muted,border:`1px solid ${T.border}`,padding:"3px 7px",fontSize:11}} onClick={()=>handleEdit(t)}>✏</button>
                        <button title="Excluir" style={{...btnS,background:T.redBg,color:T.red,padding:"3px 7px",fontSize:11}} onClick={()=>handleDelete(t.id)}>✕</button>
                      </div>
                    </td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          </div>
        </>}

        {/* ─── HISTÓRICO ─── */}
        {tab==="historico"&&<>
          <div style={{marginBottom:18}}><h1 style={{fontSize:22,fontWeight:800,letterSpacing:-1}}>Histórico Comparativo</h1></div>
          <div style={{...card,marginBottom:12}}>
            <div style={{display:"flex",gap:16,flexWrap:"wrap",alignItems:"flex-end"}}>
              <div><label style={{...lbl,marginBottom:6}}>Periodicidade</label>
                <div style={{display:"flex",gap:6}}>
                  {[{v:"mensal",l:"Mensal"},{v:"trimestral",l:"Trimestral"},{v:"anual",l:"Anual"}].map(o=>(
                    <button key={o.v} style={{...btnS,background:histMode===o.v?T.accent:"transparent",color:histMode===o.v?"#fff":T.muted,border:`1.5px solid ${histMode===o.v?T.accent:T.border}`,padding:"7px 14px"}} onClick={()=>setHistMode(o.v)}>{o.l}</button>
                  ))}
                </div>
              </div>
              <div><label style={{...lbl,marginBottom:6}}>Métrica</label>
                <div style={{display:"flex",gap:6}}>
                  {[{v:"receita",l:"Receitas",c:T.green},{v:"gasto",l:"Gastos",c:T.red},{v:"investimento",l:"Invest.",c:T.blue},{v:"saldo",l:"Saldo",c:T.purple}].map(o=>(
                    <button key={o.v} style={{...btnS,background:histMetric===o.v?o.c:"transparent",color:histMetric===o.v?"#fff":T.muted,border:`1.5px solid ${histMetric===o.v?o.c:T.border}`,padding:"7px 14px"}} onClick={()=>setHistMetric(o.v)}>{o.l}</button>
                  ))}
                </div>
              </div>
            </div>
          </div>
          <div style={{...card,marginBottom:12}}>
            <div style={{fontSize:13,fontWeight:700,marginBottom:16}}>{histMetric.charAt(0).toUpperCase()+histMetric.slice(1)} por período</div>
            <div style={{display:"flex",alignItems:"flex-end",gap:10,height:200}}>
              {histData.map((b,i)=>{
                const val=b[histMetric];const pct=maxVal>0?(Math.abs(val)/maxVal)*100:0;
                const prev=i>0?histData[i-1][histMetric]:null;
                const delta=prev&&prev!==0?((val-prev)/Math.abs(prev))*100:null;
                return(<div key={b.key} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:2}}>
                  <div style={{fontSize:9,color:T.muted,textAlign:"center",fontFamily:"'JetBrains Mono',monospace",whiteSpace:"nowrap"}}>{fmtShort(val)}</div>
                  {delta!==null&&<div style={{fontSize:9,fontWeight:700,color:delta>=0?T.green:T.red}}>{delta>=0?"▲":"▼"}{Math.abs(delta).toFixed(0)}%</div>}
                  <div style={{width:"100%",display:"flex",flexDirection:"column",justifyContent:"flex-end",height:120}}>
                    <div style={{width:"100%",background:metricColor,borderRadius:"4px 4px 0 0",height:`${pct}%`,minHeight:4,opacity:.8}}/>
                  </div>
                  <div style={{fontSize:9,color:T.muted,textTransform:"uppercase",textAlign:"center"}}>{keyLabel(b.key)}</div>
                </div>);
              })}
            </div>
          </div>
          <div style={card}>
            <div style={{fontSize:13,fontWeight:700,marginBottom:12}}>Tabela Comparativa</div>
            <div style={{overflowX:"auto"}}>
              <table style={{width:"100%",borderCollapse:"collapse",minWidth:600}}>
                <thead><tr>{["Período","Receitas","Gastos","Investimentos","Saldo","Δ vs Anterior"].map(h=>(
                  <th key={h} style={{textAlign:h==="Período"?"left":"right",fontSize:9,color:T.muted,textTransform:"uppercase",letterSpacing:.6,paddingBottom:10,borderBottom:`1px solid ${T.border}`,fontWeight:700,whiteSpace:"nowrap",padding:"0 6px 10px"}}>{h}</th>
                ))}</tr></thead>
                <tbody>{histData.map((b,i)=>{
                  const prev=i>0?histData[i-1]:null;const dSaldo=prev?b.saldo-prev.saldo:null;
                  return(<tr key={b.key} style={{borderBottom:`1px solid ${T.border}`}}>
                    <td style={{padding:"8px 6px",fontSize:12,fontWeight:700,fontFamily:"'JetBrains Mono',monospace"}}>{keyLabel(b.key)}</td>
                    <td style={{padding:"8px 6px",textAlign:"right",fontSize:11,color:T.green,fontFamily:"'JetBrains Mono',monospace"}}>{fmt(b.receita)}</td>
                    <td style={{padding:"8px 6px",textAlign:"right",fontSize:11,color:T.red,fontFamily:"'JetBrains Mono',monospace"}}>{fmt(b.gasto)}</td>
                    <td style={{padding:"8px 6px",textAlign:"right",fontSize:11,color:T.blue,fontFamily:"'JetBrains Mono',monospace"}}>{fmt(b.investimento)}</td>
                    <td style={{padding:"8px 6px",textAlign:"right",fontSize:11,fontWeight:700,color:b.saldo>=0?T.green:T.red,fontFamily:"'JetBrains Mono',monospace"}}>{fmt(b.saldo)}</td>
                    <td style={{padding:"8px 6px",textAlign:"right",fontSize:11,fontWeight:700,color:dSaldo===null?T.muted:dSaldo>=0?T.green:T.red,fontFamily:"'JetBrains Mono',monospace"}}>
                      {dSaldo===null?"—":`${dSaldo>=0?"+":"-"}${fmt(Math.abs(dSaldo))}`}
                    </td>
                  </tr>);
                })}</tbody>
              </table>
            </div>
          </div>
        </>}

        {/* ─── UPLOAD ─── */}
        {tab==="upload"&&<>
          <div style={{marginBottom:20}}>
            <h1 style={{fontSize:22,fontWeight:800,letterSpacing:-1}}>Importar PDF</h1>
            <p style={{color:T.muted,fontSize:12,marginTop:4}}>IA calibrada para faturas Santander e Porto Bank.</p>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
            <div style={card}>
              <div style={{border:`2px dashed ${T.border}`,borderRadius:12,padding:36,textAlign:"center",cursor:"pointer"}}
                onClick={()=>fileRef.current.click()} onDragOver={e=>e.preventDefault()} onDrop={e=>{e.preventDefault();const f=e.dataTransfer.files[0];if(f)handleUpload({target:{files:[f],value:""}});}}>
                <div style={{fontSize:40,marginBottom:10,color:T.accent}}>↑</div>
                <div style={{fontSize:14,fontWeight:700,color:T.accent,marginBottom:6}}>Clique ou arraste o PDF</div>
                <div style={{fontSize:11,color:T.muted}}>AAdvantage · Unique · Porto Bank · Holerites</div>
                <input ref={fileRef} type="file" accept=".pdf" style={{display:"none"}} onChange={handleUpload}/>
              </div>
              {(uploading||uploadMsg)&&<div style={{marginTop:14,padding:12,background:T.surface,borderRadius:10,border:`1px solid ${T.border}`}}>
                <div style={{fontWeight:600,fontSize:12,color:uploadMsg.startsWith("✅")?T.green:uploadMsg.startsWith("❌")?T.red:T.accent,marginBottom:6}}>{uploading&&"⏳ "}{uploadMsg||"Processando..."}</div>
                {uploadLog.length>0&&<div style={{maxHeight:120,overflowY:"auto"}}>{uploadLog.map((l,i)=><div key={i} style={{fontSize:10,color:T.muted,padding:"2px 0",borderBottom:`1px solid ${T.border}`}}>{l}</div>)}</div>}
              </div>}
            </div>
            <div style={card}>
              <div style={{fontSize:12,fontWeight:700,marginBottom:10}}>📋 Documentos já importados</div>
              {[["💳","AAdvantage Black *3313","Jan/26 (R$23.289) e Fev/26 (R$47.446)","✅"],
                ["💳","AAdvantage *4444 (Marcella)","Jan/26 e Fev/26","✅"],
                ["💳","Virtual *5073","Jan/26 e Fev/26","✅"],
                ["💳","Santander Unique *4731","Jan/26 e Fev/26","✅"],
                ["💳","Porto Bank *120","Jan, Fev e Mar/26","✅"],
                ["🏦","Holerite Mensal Santander","Jan/26 e Fev/26","✅"],
                ["💰","Folha RV Santander","Fev/26 — PLR R$573k","✅"],
              ].map(([icon,t,s,status])=>(<div key={t} style={{display:"flex",gap:10,marginBottom:8,alignItems:"flex-start"}}>
                <span style={{fontSize:16}}>{icon}</span>
                <div style={{flex:1}}><div style={{fontSize:11,fontWeight:600}}>{t}</div><div style={{fontSize:9,color:T.muted}}>{s}</div></div>
                <span style={{fontSize:12}}>{status}</span>
              </div>))}
              <div style={{marginTop:12,paddingTop:12,borderTop:`1px solid ${T.border}`,fontSize:11,color:T.muted}}>
                Arraste novos PDFs para adicionar mais períodos.
              </div>
            </div>
          </div>
        </>}

        {/* ─── CONSULTOR ─── */}
        {tab==="consultor"&&<>
          <div style={{marginBottom:18}}>
            <h1 style={{fontSize:22,fontWeight:800,letterSpacing:-1}}>Consultor Financeiro IA</h1>
            <p style={{color:T.muted,fontSize:12,marginTop:4}}>Análises baseadas em {txs.length} lançamentos reais.</p>
          </div>
          <div style={card}>
            <div style={{height:420,overflowY:"auto",display:"flex",flexDirection:"column",gap:10,padding:4,marginBottom:14}} ref={chatRef}>
              {aiChat.length===0&&(<div style={{textAlign:"center",paddingTop:40}}>
                <div style={{fontSize:40,marginBottom:10}}>✦</div>
                <div style={{fontWeight:700,fontSize:15,marginBottom:6}}>Conheço seus dados reais</div>
                <div style={{fontSize:11,color:T.muted,maxWidth:340,margin:"0 auto 18px"}}>Tenho acesso a todos os seus PDFs importados — holerites, faturas AAdvantage, Unique e Porto Bank.</div>
                <div style={{display:"flex",flexWrap:"wrap",gap:8,justifyContent:"center"}}>
                  {["Onde estou gastando mais?","Como usar o PLR de R$573k?","Quanto gasto em restaurantes?","O que é o gasto no Círculo Militar?"].map(q=>(
                    <button key={q} style={{...btnS,...btnO,fontSize:11,padding:"6px 12px"}} onClick={()=>setChatInput(q)}>{q}</button>
                  ))}
                </div>
              </div>)}
              {aiChat.map((m,i)=>(<div key={i} style={{display:"flex",justifyContent:m.role==="user"?"flex-end":"flex-start"}}>
                <div style={{background:m.role==="user"?T.accent:T.surface,color:T.text,borderRadius:m.role==="user"?"16px 16px 4px 16px":"16px 16px 16px 4px",padding:"10px 14px",maxWidth:"82%",fontSize:13,lineHeight:1.6,border:m.role==="assistant"?`1px solid ${T.border}`:"none",whiteSpace:"pre-wrap"}}>{m.text}</div>
              </div>))}
              {chatLoading&&<div style={{display:"flex"}}><div style={{background:T.surface,borderRadius:"16px 16px 16px 4px",padding:"10px 14px",fontSize:12,color:T.muted,border:`1px solid ${T.border}`}}>Analisando seus dados...</div></div>}
            </div>
            <div style={{display:"flex",gap:10}}>
              <input style={{...inp,flex:1}} placeholder="Pergunte sobre sua situação financeira..." value={chatInput} onChange={e=>setChatInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&sendChat()}/>
              <button style={btnP} onClick={sendChat} disabled={chatLoading}>→</button>
            </div>
          </div>
        </>}

      </main>
    </div>

    {modal==="reclassify"&&selectedTx&&<ReclassifyModal tx={selectedTx} allTx={txs} categories={categories} onConfirm={doReclassify} onClose={()=>{setModal(null);setSelectedTx(null);}}/>}
    {modal==="form"&&<FormModal form={form} setForm={setForm} editId={editId} categories={categories} applyRules={applyRules} onSave={saveForm} onClose={()=>setModal(null)}/>}
  </>);
}
